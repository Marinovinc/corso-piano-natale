# Suonare i canti di Natale al pianoforte — guida

`[sessione 3c88c123, 03/10/2026]` — quarto corso della serie (dopo boogie, blues e ragtime),
stessa formula. Arrangiamenti facili a due mani, con **Synthesia**.

I canti di questo corso sono brani tradizionali di **pubblico dominio**. Le **melodie** sono state
prese da fonti di notazione (ABC) e **verificate all'ascolto**; l'**arrangiamento** (melodia a destra
+ accordi semplici a sinistra) e' originale. Melodia a destra, accordi a sinistra: due tracce
separate, come negli altri corsi.

**Regola d'oro (sempre la stessa): prima la mano sinistra, da sola, lentissima.** Qui la sinistra
fa gli accordi di accompagnamento; la destra la melodia che tutti conoscono.

---

## Come preparare Synthesia

Identico agli altri corsi: cavo **USB "TO HOST"**, seleziona la tastiera come ingresso, apri il file
`.mid`, attiva la **Modalita' di attesa**, studia **una mano alla volta**. Dettagli nella guida della
cartella `Esercizi Boogie Woogie`.

---

## I canti (4, tutti in tonalita' facile)

| # | File | Tonalita' | Note |
|---|---|---|---|
| 1 | `01_Jingle_Bells` | DO | il ritornello "Jingle bells, jingle all the way" |
| 2 | `02_Joy_to_the_World` | DO | la scala discendente + "And heaven and nature sing" |
| 3 | `03_Silent_Night` | DO | la strofa completa (valzer, 3/4) |
| 4 | `04_We_Wish_You_a_Merry_Christmas` | SOL | strofa + "Good tidings we bring" (valzer, 3/4) |

Ogni file ha il suo **MP3** di ascolto: ascoltalo prima, poi suonalo. I tempi sono tranquilli
apposta; in Synthesia puoi rallentare ancora quanto vuoi.

---

## Consigli

- **La melodia la conosci gia'**: e' un vantaggio enorme. L'orecchio ti dice subito se stai
  sbagliando una nota. Usalo.
- **La sinistra fa pochi accordi** che cambiano lentamente: imparali uno alla volta, poi uniscili
  alla destra.
- Jingle Bells e Joy to the World sono in 4/4 (quattro movimenti); Silent Night e We Wish sono
  **valzer** in 3/4 (tre movimenti: *UN-due-tre*). Conta a voce alta all'inizio.

---

## Onesta' sui file

Melodie tradizionali di pubblico dominio, prese da notazione e verificate all'ascolto; arrangiamento
semplice e originale, mani separate. Sono versioni **facili per principianti**, non le armonizzazioni
da concerto. Per cominciare a suonare qualcosa che tutti riconoscono — e proprio sotto Natale — sono
un ottimo punto di partenza. Buone feste, e un tasto alla volta.
